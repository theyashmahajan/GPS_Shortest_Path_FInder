#include <iostream>
#include <map>
#include <vector>
#include <limits>
#include <algorithm>
#include <queue>

using namespace std;

const int INF = numeric_limits<int>::max();

// Structure to represent a weighted edge
struct Edge
{
    string to;
    int weight;
};

// Function to find the shortest path using Dijkstra's algorithm
void dijkstra(map<string, vector<Edge>> &graph, const string &start, const string &end)
{
    map<string, int> distance;
    map<string, string> parent;

    for (const auto &city : graph)
    {
        distance[city.first] = INF;
        parent[city.first] = "";
    }

    distance[start] = 0;
    priority_queue<pair<int, string>> pq;
    pq.push({0, start});

    while (!pq.empty())
    {
        string u = pq.top().second;
        int dist_u = -pq.top().first;
        pq.pop();

        if (dist_u > distance[u])
        {
            continue;
        }

        for (const Edge &edge : graph[u])
        {
            string v = edge.to;
            int weight = edge.weight;

            if (distance[u] + weight < distance[v])
            {
                distance[v] = distance[u] + weight;
                parent[v] = u;
                pq.push({-distance[v], v});
            }
        }
    }

    // Display the shortest path and distance
    cout << "Shortest distance from " << start << " to " << end << ": " << distance[end] << " units." << endl;

    vector<string> path;
    string current = end;
    while (current != "")
    {
        path.push_back(current);
        current = parent[current];
    }

    reverse(path.begin(), path.end());

    cout << "Shortest path: ";
    for (const string &city : path)
    {
        cout << city;
        if (city != end)
        {
            cout << " -> ";
        }
    }
    cout << endl;
}

int main()
{
    // Create a graph with distances between cities
    map<string, vector<Edge>> graph;
    graph["Mumbai"] = {{"Bangalore", 1000}, {"Delhi", 1400}, {"Chandigarh", 1500}};
    graph["Bangalore"] = {{"Mumbai", 1000}, {"Delhi", 1800}, {"Chandigarh", 1600}};
    graph["Delhi"] = {{"Mumbai", 1400}, {"Bangalore", 1800}, {"Chandigarh", 300}};
    graph["Chandigarh"] = {{"Mumbai", 1500}, {"Bangalore", 1600}, {"Delhi", 300}};

    string start, end;
    cout << "Enter the source city: ";
    cin >> start;
    cout << "Enter the destination city: ";
    cin >> end;

    if (graph.find(start) != graph.end() && graph.find(end) != graph.end())
    {
        dijkstra(graph, start, end);
    }
    else
    {
        cout << "Invalid city names entered." << endl;
    }

    return 0;
}
